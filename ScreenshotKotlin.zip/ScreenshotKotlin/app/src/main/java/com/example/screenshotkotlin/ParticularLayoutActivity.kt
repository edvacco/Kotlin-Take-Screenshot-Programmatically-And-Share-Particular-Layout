package com.example.screenshotkotlin

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Environment
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import java.io.File
import java.io.FileOutputStream
import java.util.Date

class ParticularLayoutActivity : AppCompatActivity() {

    private var btnIm: Button? = null
    private var btntx: Button? = null
    private var imageView: ImageView? = null
    private var ivpl: ImageView? = null
    private var tv: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_particular_layout)

        btnIm = findViewById(R.id.btnim)
        btntx = findViewById(R.id.btntx)
        tv = findViewById(R.id.tx)
        imageView = findViewById(R.id.image)
        ivpl = findViewById(R.id.ivpl)

        btnIm!!.setOnClickListener { takeSS(imageView) }

        btntx!!.setOnClickListener { takeSS(tv) }
    }

    private fun takeSS(v: View?) {
        val now = Date()
        android.text.format.DateFormat.format("yyyy-MM-dd_hh:mm:ss", now)

        try {
            // image naming and path  to include sd card  appending name you choose for file
            val mPath = Environment.getExternalStorageDirectory().toString() + "/" + now + ".jpeg"

            // create bitmap screen capture
            v!!.isDrawingCacheEnabled = true
            val bitmap = Bitmap.createBitmap(v.drawingCache)
            v.isDrawingCacheEnabled = false

            val imageFile = File(mPath)

            val outputStream = FileOutputStream(imageFile)
            val quality = 100
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream)
            outputStream.flush()
            outputStream.close()

            //setting screenshot in imageview
            val filePath = imageFile.path

            val ssbitmap = BitmapFactory.decodeFile(imageFile.absolutePath)
            ivpl!!.setImageBitmap(ssbitmap)
            //sharePath = filePath;

        } catch (e: Throwable) {
            // Several error may come out with file handling or DOM
            e.printStackTrace()
        }

    }
}

